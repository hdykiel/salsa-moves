---
title: "Project 1"
description: "Lorem ipsum dolor sit amet"
repo: "#" # delete this line if you want blog-like posts for projects
tags: ["go", "golang", "hugo"]
weight: 1
draft: false
---
